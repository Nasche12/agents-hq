# Contentplan KW28 (06.–12.07.2026)
**Fokus:** Webdesign & KI-Tools für kleine Unternehmen
**Erstellt:** 05.07.2026 (dritter Durchlauf, Quellen-Regel vollständig neu verifiziert)
**Quellen-Fenster (Regel 2):** 21.06.2026 – 05.07.2026, jedes Datum per `mcp__workspace__web_fetch`-Abruf im Quelltext verifiziert (Feld `article:published_time` bzw. `article:modified_time`).

---

## Wichtiger Hinweis vorab (ehrlich, keine Beschönigung)

Diese Runde hat **7 von 10 angestrebten Ideen** mit regelkonformer Quelle erreicht (siehe Rückfrage am Ende). Das ist qualitativ besser als der vorherige Lauf (dort ebenfalls 7, aber mit unsauberen "~5–10 Tage"-Schätzungen statt echten Daten) — diesmal mit **exakt verifizierten Daten und vollen URLs direkt im Dokument**, wie Regel 2 verlangt. Die Hostinger-Statistikseite, die in den Vorläufen die tragende Quelle war, wurde erneut abgerufen und zeigt weiterhin `article:published_time: 2026-05-15` (51 Tage alt) — **sie bleibt ausgeschlossen.**

---

## 7-Tage-Contentplan

### Montag, 06.07.2026 — Agentic AI übernimmt Routineaufgaben in WordPress
**Hook (erste 3 Sekunden):**
"Deine Website baut sich in 4 Minuten selbst — während du Kaffee trinkst."

**Idee:**
Elementor beschreibt in einem am 29.06.2026 aktualisierten Artikel "Angie", ein kostenloses, agentisches KI-Framework für WordPress, das über das Model Context Protocol (MCP) automatisch den vollen Website-Kontext übernimmt und Aufgaben in natürlicher Sprache plant, schreibt und ausführt — inklusive Custom-Widgets in ca. 4 Minuten von Idee bis Produktion. Für kleine Unternehmen: Repetitive WordPress-Arbeit verschwindet, Zeit bleibt für Strategie.

**Quelle:** https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ — verifiziertes Datum: 29.06.2026 (`article:modified_time`)

**Format:** Screen-Recording-Demo (30–40 Sekunden)
**Plattform:** YouTube Shorts / LinkedIn

---

### Dienstag, 07.07.2026 — Barrierefreiheit auf Knopfdruck: 70 % der Fehler automatisch behoben
**Hook (erste 3 Sekunden):**
"98 % aller Websites haben Barrierefreiheits-Fehler. KI behebt jetzt 70 % davon automatisch."

**Idee:**
Laut demselben Elementor-Artikel (29.06.2026) können KI-gestützte Remediation-Tools inzwischen automatisch bis zu 70 % gängiger Barrierefreiheits-Probleme erkennen und beheben — von fehlenden Alt-Texten bis zu Farbkontrast-Verstößen. Für kleine Unternehmen im DACH-Raum ist das doppelt relevant: Es senkt den Aufwand für WCAG-Konformität und ist gleichzeitig ein Trust-Signal für Kunden.

**Quelle:** https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ — verifiziertes Datum: 29.06.2026 (`article:modified_time`)

**Format:** Tutorial / Vorher-Nachher (30 Sekunden)
**Plattform:** Instagram Reels / LinkedIn

---

### Mittwoch, 08.07.2026 — Hyper-Personalisierung: Websites, die sich in Echtzeit anpassen
**Hook (erste 3 Sekunden):**
"Zwei Besucher, zwei komplett verschiedene Startseiten — automatisch."

**Idee:**
Der Elementor-Artikel (29.06.2026) beschreibt, wie KI in Echtzeit Header, Bilder und Call-to-Actions je nach Besucherverhalten anpasst — laut zitierter McKinsey-Analyse ein Conversion-Plus von bis zu 15 %. Für kleine Online-Shops und Dienstleister: Ein Erstbesucher von Social Media sieht andere Inhalte als ein wiederkehrender Kunde mit Warenkorb.

**Quelle:** https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ — verifiziertes Datum: 29.06.2026 (`article:modified_time`)

**Format:** Erklär-Video mit Split-Screen (30 Sekunden)
**Plattform:** TikTok / Instagram Reels

---

### Donnerstag, 09.07.2026 — DESIGN.md: Die Bedienungsanleitung für deinen KI-Coding-Assistenten
**Hook (erste 3 Sekunden):**
"Deine KI baut jedes Mal eine andere Website? Eine Datei löst das."

**Idee:**
Ein Artikel vom 01.07.2026 beschreibt DESIGN.md: eine einfache Markdown-Datei im Projekt, die Farben, Typografie, Abstände, Komponenten und Barrierefreiheits-Regeln so dokumentiert, dass KI-Coding-Agenten (Claude Code, Cursor, Copilot) konsistent im Corporate Design bauen — statt bei jedem Prompt neu zu improvisieren. Für Freelancer und kleine Agenturen: weniger Nacharbeit, konsistentere Kundenprojekte.

**Quelle:** https://blog.mean.ceo/design-md-news-july-2026/ — verifiziertes Datum: 01.07.2026 (`article:published_time`)

**Format:** Tutorial mit Beispiel-Datei (40–50 Sekunden)
**Plattform:** LinkedIn / YouTube Shorts

---

### Freitag, 10.07.2026 — Figma bleibt die Zentrale: 82 % der UI-Designer arbeiten damit
**Hook (erste 3 Sekunden):**
"Ein Tool, das 82 % aller UI-Designer täglich öffnen — auch 2026 noch."

**Idee:**
Ein Artikel vom 02.07.2026 zitiert eine UX-Tools-Umfrage: 82,3 % der UI-Designer nutzen Figma, 82,6 % wöchentlich. Der Artikel argumentiert, Figma sei nicht mehr "nur" ein Design-Tool, sondern die zentrale Abstimmungs-Oberfläche zwischen Gründer:innen, Freelancer:innen, Entwickler:innen und Kunden. Für kleine Teams: ein gemeinsamer Ort für Feedback statt PDF-Chaos.

**Quelle:** https://blog.mean.ceo/design-tool-of-the-month-news-july-2026/ — verifiziertes Datum: 02.07.2026 (`article:published_time`)

**Format:** Carousel / Vergleichs-Post (3–4 Slides)
**Plattform:** LinkedIn / Instagram

---

### Samstag, 11.07.2026 — Welches KI-Tool lohnt sich für Solo-Gründer:innen wirklich?
**Hook (erste 3 Sekunden):**
"ChatGPT, Krater.ai oder eesel? Die Antwort hängt von deiner Aufgabe ab, nicht vom Hype."

**Idee:**
Ein Artikel vom 02.07.2026 empfiehlt Solo-Gründer:innen und Freelancer:innen, zunächst ein einziges Allround-Tool zu wählen (ChatGPT als meistgenutzte Option laut Artikel) und erst nach zwei Wochen echtem Bedarf ein Spezial-Tool zu ergänzen (z. B. Perplexity für Recherche, Cursor für Code). Die zentrale Warnung des Artikels: Tools nicht nach Hype, sondern nach wiederkehrenden Wochenaufgaben auswählen.

**Quelle:** https://blog.mean.ceo/ai-tool-of-the-month-news-july-2026/ — verifiziertes Datum: 02.07.2026 (`article:published_time`)

**Format:** Entscheidungs-Flowchart als Kurzvideo (30 Sekunden)
**Plattform:** Instagram Reels / TikTok

---

### Sonntag, 12.07.2026 — Generative UI: Vom Prompt zur fertigen Sektion in 45 Sekunden
**Hook (erste 3 Sekunden):**
"Eine Preistabelle bauen? Tippen, warten, fertig — in 45 Sekunden."

**Idee:**
Laut dem Elementor-Artikel (29.06.2026) können generative UI-Tools aus einem Text-Prompt ("Preistabelle für SaaS mit drei Stufen") direkt fertige, produktionsreife Sektionen erzeugen. Professionelle Designer:innen berichten laut Artikel von 30–50 % Zeitersparnis beim Layout-Entwurf. Für kleine Unternehmen ohne Design-Team: schnellerer Weg von Idee zu Landingpage.

**Quelle:** https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ — verifiziertes Datum: 29.06.2026 (`article:modified_time`)

**Format:** Live-Prompt-Demo (30 Sekunden)
**Plattform:** TikTok / YouTube Shorts

---

## Ideenpool (Zusammenfassung der 7 regelkonformen Ideen)

| # | Idee | Quelle (volle URL) | Verifiziertes Datum | Fakt-Check |
|---|------|---------------------|----------------------|------------|
| 1 | Agentic AI / Angie für WordPress | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | bestanden |
| 2 | Automatisierte WCAG-Fixes (70 %) | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | bestanden |
| 3 | Hyper-Personalisierung (+15 % Conversion) | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | bestanden |
| 4 | DESIGN.md als KI-Design-Brief | https://blog.mean.ceo/design-md-news-july-2026/ | 01.07.2026 | bestanden |
| 5 | Figma-Dominanz (82,3 % Nutzung) | https://blog.mean.ceo/design-tool-of-the-month-news-july-2026/ | 02.07.2026 | bestanden |
| 6 | KI-Tool-Auswahl für Solo-Gründer:innen | https://blog.mean.ceo/ai-tool-of-the-month-news-july-2026/ | 02.07.2026 | bestanden |
| 7 | Generative UI (30–50 % Zeitersparnis) | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | bestanden |

**Transparenz-Hinweis zur Elementor-Quelle:** Der Artikel wurde ursprünglich am 04.05.2026 veröffentlicht (`article:published_time`), aber am 29.06.2026 inhaltlich aktualisiert (`article:modified_time`) — dieses Feld liegt im 14-Tage-Fenster. Wir werten das als regelkonform, weil Regel 2 explizit "Veröffentlichungs-/Änderungsdatum" zulässt, kennzeichnen es hier aber offen, damit Sebastian das selbst bewerten kann. Falls das strenger ausgelegt werden soll (nur `published_time` zählt), fallen die Ideen 1, 2, 3 und 7 weg — dann blieben nur 3 regelkonforme Ideen (4, 5, 6).

---

## Verworfene Quellen/Ideen (mit Begründung, erneut geprüft am 05.07.2026)

| Quelle | Geprüftes Datum | Alter | Grund für Ausschluss |
|--------|------------------|-------|------------------------|
| hostinger.com/blog/ai-website-builder-statistics | 15.05.2026 (published & modified) | 51 Tage | Außerhalb 14-Tage-Fenster — erneut per web_fetch bestätigt |
| wolpersweb.de (BFSG 2026) | 13.05.2026 (published), 18.05.2026 (modified) | 48/48 Tage | Außerhalb Fenster |
| fabian-reiter.com (BFSG 2026 KMU) | 03.06.2026 (im Text sichtbar) | 32 Tage | Außerhalb Fenster |
| jimdo.com (Checkliste Website-Konformität 2026) | 03.03.2026 (published), 07.04.2026 (modified) | 89/59 Tage | Außerhalb Fenster |
| paigemaddendesign.com (Small Business Trends 2026) | 30.03.2026 (im Text sichtbar) | 97 Tage | Außerhalb Fenster |
| webdesign-journal.de (aus Vorlauf) | 26.–27.05.2026 | ~40 Tage | Außerhalb Fenster (bereits in Vorlauf verworfen) |
| chilledsites.com (aus Vorlauf) | 10.08.2026 | Zukunftsdatum | Ungültig |

---

## Akzeptanzkriterien-Status (ehrlich, ohne Aufweichung — Regel 6)

- [x] contentplan.md deckt 7 Tage ab: Montag–Sonntag, je Idee + ausformulierter Hook + Format + Plattform
- [ ] **Mindestens 10 Ideen mit Quelle ≤14 Tage: NICHT ERFÜLLT.** 7 Ideen aus 3 unabhängigen, verifizierten Artikeln (4 der 7 Ideen hängen an einer strittigen `modified_time`; im strengen Fall bleiben nur 3 Ideen ohne jede Diskussion)
- [x] Keine heiklen Themen enthalten
- [x] Wochen-Fokus genannt: "Webdesign & KI-Tools für kleine Unternehmen" (von Sebastian für KW28 vorgegeben)
- [x] Sprache Deutsch, nichts veröffentlicht
- [x] Jede Idee mit voller URL + verifiziertem Datum direkt im Dokument (Regel 2)

**RÜCKFRAGE AN SEBASTIAN:**
1. Zählt bei Regel 2 auch `article:modified_time`, wenn der Artikel ursprünglich älter ist? Falls ja: 7 Ideen stehen (aus 3 Artikeln). Falls nein (nur Erstveröffentlichung zählt): nur 3 Ideen bleiben regelkonform (aus 2 Artikeln).
2. Soll ich für KW29 den Fokus bewusst breiter fassen (z. B. zusätzlich E-Commerce oder Local SEO), um mehr unabhängige Quellen im 14-Tage-Fenster zu finden? Das Nischenthema "Webdesign & KI für KMU" hat im aktuellen 14-Tage-Fenster nur eine begrenzte Zahl neu veröffentlichter, seriöser Primärquellen — auffällig viele Trend-Artikel stammen aus März–Mai 2026.
3. Akzeptierst du 7 (bzw. im strengen Fall 3) belegte Ideen statt 10, wenn dafür jede Quelle wasserdicht ist?

---

**Erstellt von:** content-recherche Agent (dritter, finaler Korrekturlauf)
**Datum:** 05.07.2026
**Status:** Ehrlich unvollständig gegenüber 10er-Ziel, vollständig regelkonform bei den vorhandenen Ideen
