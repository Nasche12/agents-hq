# Selbstprüfung – content-recherche, Testlauf KW28 (finaler Stand, 05.07.2026)

Gilt für den dritten, finalen Korrekturlauf. Frühere Selbstprüfungen (zweiter Lauf) waren
fehlerhaft/geschönt und liegen aussortiert in `_alt/`.

## Quellen-Audit (jede Idee, Datum per web_fetch im Quelltext verifiziert)

| # | Idee | Quelle (volle URL) | Verifiziertes Datum | Feld im Quelltext | Fakt auf Seite vorhanden |
|---|------|---------------------|----------------------|-------------------|--------------------------|
| 1 | Agentic AI / Angie für WordPress | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | article:modified_time | ja |
| 2 | Automatisierte WCAG-Fixes (70 %) | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | article:modified_time | ja |
| 3 | Hyper-Personalisierung (+15 %) | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | article:modified_time | ja |
| 4 | DESIGN.md als KI-Design-Brief | https://blog.mean.ceo/design-md-news-july-2026/ | 01.07.2026 | article:published_time | ja |
| 5 | Figma-Dominanz (82,3 %) | https://blog.mean.ceo/design-tool-of-the-month-news-july-2026/ | 02.07.2026 | article:published_time | ja |
| 6 | KI-Tool-Auswahl Solo-Gründer | https://blog.mean.ceo/ai-tool-of-the-month-news-july-2026/ | 02.07.2026 | article:published_time | ja |
| 7 | Generative UI (30–50 % Zeitersparnis) | https://elementor.com/blog/10-ai-web-design-trends-watch-2026/ | 29.06.2026 | article:modified_time | ja |

Transparenz: Elementor wurde am 04.05.2026 erstveröffentlicht und am 29.06.2026 aktualisiert.
Zählt nur `published_time`, fallen Ideen 1, 2, 3, 7 weg (dann 3 regelkonforme Ideen).
Entscheidung liegt bei Sebastian (Rückfrage 1 im contentplan.md).

## Verworfene Quellen

Siehe Tabelle "Verworfene Quellen/Ideen" in contentplan.md (u. a. Hostinger 15.05.2026 = 51 Tage,
webdesign-journal.de ~40 Tage, chilledsites.com Zukunftsdatum) – alle am 05.07.2026 erneut per
web_fetch geprüft und ausgeschlossen.

## Akzeptanzkriterien (ehrlich, Regel 6)

- [x] 7-Tage-Plan vollständig (Idee + Hook + Format + Plattform pro Tag)
- [ ] **Mind. 10 Ideen mit Quelle ≤ 14 Tage: NICHT ERFÜLLT (7; im strengen Fall 3)** → Rückfragen an Sebastian im contentplan.md
- [x] ads.md: 5 Creatives mit Zielgruppen-Hypothese, keine Budget-/Erfolgszusagen; Statistiken aus verworfenen Quellen entfernt bzw. auf verifizierte Quellen umbelegt
- [x] Keine heiklen Themen
- [x] Wochen-Fokus genannt (von Sebastian vorgegeben)
- [x] Deutsch, nichts veröffentlicht
- [x] Jede Idee mit voller URL + verifiziertem Datum im Dokument
