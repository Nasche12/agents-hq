# TESTLAUF MIT BEISPIELDATEN
# E-Mail-Entwurf: ferienhaus-tirol.at Wochenreport KW26

---

**Betreff:** Wochenreport ferienhaus-tirol.at – KW26 (22.–28.06.2026)

---

Liebe/r [Kundenname],

anbei erhalten Sie den Wochenreport für **ferienhaus-tirol.at** der Kalenderwoche 26 (22. bis 28. Juni 2026).

## Highlights der Woche

✓ **412 Besucher** – Anstieg um 8,1 % gegenüber der Vorwoche  
✓ **1.287 Seitenaufrufe** – kontinuierliches organisches Wachstum  
✓ **94 Sekunden** durchschnittliche Besuchsdauer – um 5,6 % verbessert  

Die Seite entwickelt sich erfreulich. Google-Suche bleibt mit 59 % die Hauptquelle, und Booking.com trägt zuverlässig etwa 10 % des Traffics bei.

Detaillierte Analyse und Tabellen finden Sie im beigefügten PDF-Report.

**Bei Fragen:** Gerne helfe ich weiter.

Viele Grüße,  
[Absender]
