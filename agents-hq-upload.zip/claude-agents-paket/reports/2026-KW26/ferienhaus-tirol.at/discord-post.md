# TESTLAUF MIT BEISPIELDATEN
# Discord-Post: ferienhaus-tirol.at KW26

---

📊 **ferienhaus-tirol.at** – Wochenreport KW26 (22.–28.06.2026)

**Besucher:** 412 (+8,1 % vs. VW)  
**Seitenaufrufe:** 1.287 (+8,2 % vs. VW)  
**Ø Dauer:** 94 Sek (+5,6 % vs. VW)

🔍 **Top Traffic-Quellen:**
• Google: 244 Besucher (59,2 %)
• Direkt: 98 (23,8 %)
• Booking.com: 41 (10,0 %)

✅ Solide Woche. Organisches Google-Wachstum stabil, Besucherdauer leicht verbessert.

Report: `#reports`
