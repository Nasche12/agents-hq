# TESTLAUF MIT BEISPIELDATEN
# Wochenreport ferienhaus-tirol.at – KW26 (22.06.–28.06.2026)

## Zeitraum
**22. Juni – 28. Juni 2026** (Montag bis Sonntag)

## Kernkennzahlen

| Metrik | Diese Woche | Vorwoche | Veränderung |
|--------|------------|----------|------------|
| Besucher | 412 | 381 | +8,1 % |
| Seitenaufrufe | 1.287 | 1.190 | +8,2 % |
| Ø Besuchsdauer | 94 Sek | 89 Sek | +5,6 % |

## Top 5 Seiten

1. **Startseite** – 402 Aufrufe
2. **Preise** – 213 Aufrufe
3. **Galerie** – 198 Aufrufe
4. **Anfrage** – 122 Aufrufe
5. **Lage** – 87 Aufrufe

## Top 5 Traffic-Quellen

1. **Google** – 244 Besucher (59,2 %)
2. **Direkt** – 98 Besucher (23,8 %)
3. **Booking.com** – 41 Besucher (10,0 %)
4. **Instagram** – 18 Besucher (4,4 %)
5. **Bing** – 11 Besucher (2,7 %)

## Analyse

Solide Woche mit moderatem Wachstum. Alle Kennzahlen zeigen einen leichten Anstieg gegenüber der Vorwoche:
- Besucherzahlen um 8,1 % gestiegen
- Seitenaufrufe um 8,2 % gestiegen  
- Besuchsdauer um 5,6 % verlängert

**Google bleibt dominante Quelle** – über 59 % des Traffics stammen aus organischer Suche. Die Startseite und Preisseite sind weiterhin die meistbesuchten Bereiche. Booking.com als Partner-Referrer trägt stabil ~10 % bei.

Keine auffälligen Ausreißer oder Anomalien erkannt.
