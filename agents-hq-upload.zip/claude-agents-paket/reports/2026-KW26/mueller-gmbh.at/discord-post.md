# TESTLAUF MIT BEISPIELDATEN
# Discord-Post: mueller-gmbh.at KW26

---

⚠️ **mueller-gmbh.at** – Wochenreport KW26 (22.–28.06.2026)

**Besucher:** 96 (-42,2 % vs. VW)  
**Seitenaufrufe:** 241 (-43,7 % vs. VW)  
**Ø Dauer:** 61 Sek (-15,3 % vs. VW)

🔍 **Ausreißer-Analyse:**
• Facebook-Kampagne am 21.06. ausgelaufen (62 → 9 Besucher, -85,5 %)
• Google stabil (54 → 51, -5,6 %)
• Direkt unverändert (31 → 30, -3,2 %)

✓ **Ursache identifiziert:** Kein technisches Problem. Organische Quellen stabil.

📋 Report mit Empfehlungen: `#reports`
