# TESTLAUF MIT BEISPIELDATEN
# Wochenreport mueller-gmbh.at – KW26 (22.06.–28.06.2026)

## Zeitraum
**22. Juni – 28. Juni 2026** (Montag bis Sonntag)

## Kernkennzahlen

| Metrik | Diese Woche | Vorwoche | Veränderung |
|--------|------------|----------|------------|
| Besucher | 96 | 166 | -42,2 % |
| Seitenaufrufe | 241 | 428 | -43,7 % |
| Ø Besuchsdauer | 61 Sek | 72 Sek | -15,3 % |

## Top 5 Seiten

1. **Startseite** – 101 Aufrufe
2. **Leistungen** – 58 Aufrufe
3. **Kontakt** – 39 Aufrufe
4. **Über uns** – 26 Aufrufe
5. **Impressum** – 17 Aufrufe

## Top 5 Traffic-Quellen (diese Woche)

1. **Google** – 51 Besucher (53,1 %)
2. **Direkt** – 30 Besucher (31,3 %)
3. **Facebook** – 9 Besucher (9,4 %)
4. **Bing** – 6 Besucher (6,3 %)

## Top 5 Traffic-Quellen (Vorwoche zum Vergleich)

1. **Facebook** – 62 Besucher (37,3 %)
2. **Google** – 54 Besucher (32,5 %)
3. **Direkt** – 31 Besucher (18,7 %)
4. **Bing** – 8 Besucher (4,8 %)

## Analyse – Ausreißer erkannt (>30 % Abweichung)

**Deutlicher Rückgang um -42,2 % bei Besuchern und -43,7 % bei Seitenaufrufen.**

Ursache klar identifiziert:
- **Facebook-Traffic ist um 85,5 % gefallen** (von 62 auf 9 Besucher)
- Die Facebook-Referrer-Kampagne ist am 21.06.2026 ausgelaufen
- Gleichzeitig ist Google-Traffic nahezu stabil (leicht gesunken) (54 → 51 Besucher, -5,6 %)
- Direkter Zugriff unverändert (31 → 30 Besucher, -3,2 %)

**Interpretation:** Der Rückgang ist vollständig durch das Auslaufen der Facebook-Kampagne erklärbar und kein Zeichen für technische Probleme oder Qualitätsmängel. Organische Quellen (Google, direkt) sind stabil.

**Empfehlung:** Prüfen Sie, ob eine neue Facebook-Kampagne geplant ist oder ob die Investition in andere Kanäle (z.B. Google Ads, organische Suchoptimierung) erwünscht ist.
